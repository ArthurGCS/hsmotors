<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>HS Motors - Área Administrativa</h5>
                <p>Sistema de Gerenciamento de Clientes e Veículos</p>
            </div>
            <div class="col-md-6 text-md-end">
                <p>&copy; <?php echo date('Y'); ?> HS Motors. Todos os direitos reservados.</p>
            </div>
        </div>
    </div>
</footer>

